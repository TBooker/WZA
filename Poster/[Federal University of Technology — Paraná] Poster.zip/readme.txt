This LaTeX template (unofficial) allows the poster production of the Federal University of Technology — Paraná (UTFPR).

It was developed based on the beamer class, available at <http://ctan.org/pkg/beamer/>, and the beamerposter package, available at <http://ctan.org/pkg/beamerposter/>, as well as several code snippets developed by TeX-LaTeX Stack Exchange users, available at <http://tex.stackexchange.com/>.

Status: added by Luiz E. M. Lima, maintenance on demand.
Last updated: December 1, 2019 (Version 1.1).


Este modelo LaTeX (não oficial) permite a produção de poster da Universidade Tecnológica Federal do Paraná (UTFPR).

Foi desenvolvido baseado na classe beamer, disponível em <http://ctan.org/pkg/beamer/>, e no pacote beamerposter, disponível em <http://ctan.org/pkg/beamerposter/>, bem como em diversos trechos de códigos desenvolvidos por usuários do TeX-LaTeX Stack Exchange, disponível em <http://tex.stackexchange.com/>.

Estado: adicionado por Luiz E. M. Lima, manutenção sob demanda.
Última atualização: 1 de dezembro de 2019 (Versão 1.1).
